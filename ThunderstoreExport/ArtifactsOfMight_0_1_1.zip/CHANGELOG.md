# Changelog


## 0.1.1

- fixing links in the readme by using imgur source

## 0.1.0

- Initial Release
